package com.employee.model;

/**
 * Employee.java
 * This is a model class represents a Employee entity
 *
 */
public class Employee {
	protected int empNo;
	protected String name;
	protected String department;
	protected int exp_years;
	protected String qualifications;
	protected String certifications;
	protected String tech_skills;

	public Employee() {
	}
	
	public Employee(String name, String department, int exp_years, String qualifications, String certifications, String tech_skills) {
		super();
		this.name = name;
		this.department = department;
		this.exp_years = exp_years;
		this.qualifications = qualifications;
		this.certifications = certifications;
		this.tech_skills = tech_skills;
	}

	public Employee(int empNo, String name, String department, int exp_years, String qualifications, String certifications, String tech_skills) {
		super();
		this.empNo = empNo;
		this.name = name;
		this.department = department;
		this.exp_years = exp_years;
		this.qualifications = qualifications;
		this.certifications = certifications;
		this.tech_skills = tech_skills;
	}

	public int getEmpNo() {
		return empNo;
	}

	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public int getExp_years() {
		return exp_years;
	}

	public void setExp_years(int exp_years) {
		this.exp_years = exp_years;
	}

	public String getQualifications() {
		return qualifications;
	}

	public void setQualifications(String qualifications) {
		this.qualifications = qualifications;
	}

	public String getCertifications() {
		return certifications;
	}

	public void setCertifications(String certifications) {
		this.certifications = certifications;
	}

	public String getTech_skills() {
		return tech_skills;
	}

	public void setTech_skills(String tech_skills) {
		this.tech_skills = tech_skills;
	}
}