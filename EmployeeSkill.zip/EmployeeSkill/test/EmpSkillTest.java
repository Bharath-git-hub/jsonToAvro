import com.employee.dao.EmployeeDAO;
import com.employee.model.Employee;
import com.employee.web.EmployeeServlet;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;

public class EmpSkillTest {

    @Mock
    HttpServletRequest request;
    @Mock
    HttpServletResponse response;
    @Mock
    HttpSession session;

    @Mock
    RequestDispatcher rd;

    private final EmployeeDAO empDAO = Mockito.mock(EmployeeDAO.class);

    EmployeeServlet es  = new EmployeeServlet();

    public Employee emp;
    public List<Employee> emplist;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        //es.init();
        emp = new Employee();
        emp.setEmpNo(1);
        emp.setName("Ajay");
        emp.setDepartment("Sales");
        emp.setQualifications("BE");
        emp.setCertifications("java");
        emp.setTech_skills("java");

        emplist = new ArrayList<>();
        emplist.add(emp);
    }

    @Test
    public void test_new_form() throws Exception {
        when(request.getServletPath()).thenReturn("/new");
        when(request.getSession()).thenReturn(session);
        when(request.getRequestDispatcher("employee-form.jsp")).thenReturn(rd);

        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);

        when(response.getWriter()).thenReturn(pw);

        new EmployeeServlet().doPost(request, response);

        verify(rd).forward(request, response);

        String result = sw.getBuffer().toString().trim();

        //Result will be blank as it is new form
        Assert.assertEquals("", result);
    }

    @Test
    public void test_list_employees() throws Exception {
        when(request.getServletPath()).thenReturn("/");
        when(request.getSession()).thenReturn(session);
        when(request.getRequestDispatcher("employee-list.jsp")).thenReturn(rd);

        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);

        es.employeeDAO = empDAO;
        when(empDAO.selectAllEmployees()).thenReturn(emplist);

        when(response.getWriter()).thenReturn(pw);

        es.doPost(request, response);
        //verifying response is forwarded to employee list jsp
        verify(rd).forward(request, response);
    }

    @Test
    public void test_showEditForm() throws Exception {
        when(request.getServletPath()).thenReturn("/edit");
        when(request.getSession()).thenReturn(session);
        when(request.getParameter("empNo")).thenReturn("1");
        es.employeeDAO = empDAO;
        when(empDAO.selectEmployee(1)).thenReturn(emp);
        when(request.getRequestDispatcher("employee-form.jsp")).thenReturn(rd);

        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);

        when(response.getWriter()).thenReturn(pw);

        es.doPost(request, response);
        //verify edit navigates to employee
        verify(rd).forward(request, response);
    }

    @Test
    public void test_insert() throws Exception {
        when(request.getServletPath()).thenReturn("/insert");
        when(request.getSession()).thenReturn(session);
        when(request.getParameter("empNo")).thenReturn("1");
        when(request.getParameter("department")).thenReturn("test");
        when(request.getParameter("name")).thenReturn("test");
        when(request.getParameter("exp_years")).thenReturn("1");
        when(request.getParameter("qualifications")).thenReturn("1");
        when(request.getParameter("certifications")).thenReturn("1");
        when(request.getParameter("tech_skills")).thenReturn("1");
        es.employeeDAO = empDAO;
        doNothing().when(empDAO).insertEmployee(Mockito.any(Employee.class));
        when(request.getRequestDispatcher("employee-form.jsp")).thenReturn(rd);

        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);

        when(response.getWriter()).thenReturn(pw);

        es.doPost(request, response);
        //verify edit navigates to employee
        verify(response).sendRedirect("list");
    }

    @Test
    public void test_update() throws Exception {
        when(request.getServletPath()).thenReturn("/update");
        when(request.getSession()).thenReturn(session);
        when(request.getParameter("empNo")).thenReturn("1");
        when(request.getParameter("department")).thenReturn("test");
        when(request.getParameter("name")).thenReturn("test");
        when(request.getParameter("exp_years")).thenReturn("1");
        when(request.getParameter("qualifications")).thenReturn("1");
        when(request.getParameter("certifications")).thenReturn("1");
        when(request.getParameter("tech_skills")).thenReturn("1");
        es.employeeDAO = empDAO;
        when(empDAO.updateEmployee(Mockito.any(Employee.class))).thenReturn(true);
        when(request.getRequestDispatcher("employee-form.jsp")).thenReturn(rd);

        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);

        when(response.getWriter()).thenReturn(pw);

        es.doPost(request, response);
        //verify edit navigates to employee
        verify(response).sendRedirect("list");
    }

    @Test
    public void test_delete() throws Exception {
        when(request.getServletPath()).thenReturn("/delete");
        when(request.getSession()).thenReturn(session);
        when(request.getParameter("empNo")).thenReturn("1");
        es.employeeDAO = empDAO;
        when(empDAO.deleteEmployee(1)).thenReturn(true);
        when(request.getRequestDispatcher("employee-form.jsp")).thenReturn(rd);

        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);

        when(response.getWriter()).thenReturn(pw);

        es.doPost(request, response);
        //verify edit navigates to employee
        verify(response).sendRedirect("list");
    }
}
